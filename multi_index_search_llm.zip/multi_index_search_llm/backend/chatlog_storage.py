import boto3
import json
import gzip
import uuid
import config
import redis
import io
import time
from botocore.exceptions import ClientError
from functools import lru_cache
import logging

logger = logging.getLogger(config.APP_NAME)

try:
    from celery_app import celery_app
    logger.info("celery_app imported successfully in chatlog_storage.")
except ImportError:
    logger.error("Could not import celery_app in chatlog_storage.")
    celery_app = None # Allow file to be imported without Celery for non-worker processes

# AWS and Redis config
bucket_name = config.AWS_BUCKET_NAME
try:
    log_buffer_threshold = int(config.LOG_BUFFER_THRESHOLD)
    log_buffer_ttl_seconds = int(config.LOG_BUFFER_TTL_SECONDS)
except (TypeError, ValueError):
    log_buffer_threshold = 100
    log_buffer_ttl_seconds = 3600

# Redis Initialization
redis_client = None
try:
    redis_client = redis.StrictRedis(
        host=config.REDIS_HOST, port=config.REDIS_PORT, db=config.REDIS_DB, decode_responses=False
    )
    redis_client.ping()
except Exception as e:
     logger.error(f"Redis connection failed: {e}. Chatlog buffering will likely fail.", exc_info=True)

@lru_cache(maxsize=1)
def get_s3_client():
    try:
        return boto3.client('s3')
    except Exception as e:
        logger.error(f"Failed to create S3 client: {e}", exc_info=True)
        return None

def get_utc_iso_timestamp():
     return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()) + "Z"

def generate_s3_key(chat_id):
    date_folder = time.strftime("%Y-%m-%d", time.gmtime())
    uid = uuid.uuid4().hex[:8]
    return f"chatlogs/{date_folder}/{chat_id}/batch_{int(time.time())}_{uid}.json.gz"

def compress_json_payload(log_entries):
    try:
        json_bytes = json.dumps(log_entries).encode('utf-8')
        out = io.BytesIO()
        with gzip.GzipFile(fileobj=out, mode="wb") as f:
            f.write(json_bytes)
        return out.getvalue()
    except Exception as e:
         logger.error(f"Error during JSON compression: {e}", exc_info=True)
         return None

if celery_app:
    @celery_app.task(bind=True, max_retries=3, default_retry_delay=60, acks_late=True)
    def store_batch_chat_logs_task(self, chat_id):
        if not redis_client:
            logger.error(f"Redis client not available. Cannot store logs for chat_id: {chat_id}")
            return {"status": "failed_no_redis", "chat_id": chat_id}
        
        redis_key = f"{config.REDIS_LOG_LIST_KEY_PREFIX}{chat_id}"
        
        try:
            log_entries_bytes = redis_client.lrange(redis_key, 0, -1)
            if not log_entries_bytes: return {"status": "no_logs_found", "chat_id": chat_id}
            
            log_entries = [json.loads(entry.decode('utf-8')) for entry in log_entries_bytes]
            if not log_entries:
                try: redis_client.delete(redis_key)
                except Exception as del_e: logger.error(f"Redis error on cleanup: {del_e}")
                return {"status": "decoding_failed", "chat_id": chat_id}

            compressed_payload = compress_json_payload(log_entries)
            if not compressed_payload: raise ValueError("Compression failed")

            s3_key = generate_s3_key(chat_id)
            s3 = get_s3_client()
            if not s3: raise ConnectionError("S3 client unavailable.")

            s3.put_object(Bucket=bucket_name, Key=s3_key, Body=compressed_payload, ContentType='application/json', ContentEncoding='gzip')
            
            try: redis_client.delete(redis_key)
            except Exception as del_e: logger.error(f"Redis key deletion failed after S3 upload: {del_e}")

            return {"status": "success", "s3_path": f"s3://{bucket_name}/{s3_key}", "count": len(log_entries)}
        except Exception as e:
            logger.error(f"Error in store_batch_chat_logs_task for {chat_id}: {e}", exc_info=True)
            raise self.retry(exc=e)

def buffer_chat_log(chat_id, user, message):
    if not redis_client:
        logger.warning(f"Redis not available. Cannot buffer log for chat_id: {chat_id}")
        return

    log_entry = {'timestamp': get_utc_iso_timestamp(), 'user': user, 'message': message}
    key = f"{config.REDIS_LOG_LIST_KEY_PREFIX}{chat_id}"

    try:
        entry_bytes = json.dumps(log_entry).encode('utf-8')
        pipeline = redis_client.pipeline()
        pipeline.rpush(key, entry_bytes)
        pipeline.expire(key, log_buffer_ttl_seconds)
        results = pipeline.execute()
        current_length = results[0]

        if current_length >= log_buffer_threshold and celery_app:
            logger.info(f"Log buffer threshold reached for {chat_id}. Triggering S3 storage task.")
            store_batch_chat_logs_task.delay(chat_id)
    except Exception as e:
        logger.error(f"Error buffering chat log for {chat_id}: {e}", exc_info=True)