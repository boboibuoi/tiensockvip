import logging
import config
import re
import json
from qdrant_client import QdrantClient
from qdrant_client.http import models
from sentence_transformers import SentenceTransformer
from openai import OpenAI
from tenacity import retry, stop_after_attempt, wait_fixed

# NEW: Import the prompt template function
from backend.prompt_templates import get_filter_extraction_prompt

# Setup logger
logger = logging.getLogger(config.APP_NAME)

# --- Initialize Sentence Transformer Model ---
try:
    embedding_model = SentenceTransformer(config.LOCAL_EMBEDDING_MODEL_NAME)
    logger.info(f"Successfully loaded sentence-transformer model in context_layer: {config.LOCAL_EMBEDDING_MODEL_NAME}")
except Exception as e:
    logger.critical(f"Failed to load sentence-transformer model in context_layer: {e}", exc_info=True)
    embedding_model = None

# --- Configuration for Context Relevance ---
relevance_threshold = 0.70

# --- LLM Helper for Filter Extraction ---
@retry(stop=stop_after_attempt(2), wait=wait_fixed(1))
def get_filters_from_llm(query: str) -> dict:
    """
    Uses an LLM to analyze the user's query and extract structured filters as a JSON object.
    """
    try:
        client = OpenAI(api_key=config.MISTRAL_API_KEY, base_url="https://api.mistral.ai/v1")
        
        # --- MODIFIED: Call the prompt template function ---
        system_prompt, user_prompt = get_filter_extraction_prompt(query)
        
        response = client.chat.completions.create(
            model=config.MISTRAL_MODEL, #
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.0,
            response_format={"type": "json_object"}
        )
        
        response_text = response.choices[0].message.content
        return json.loads(response_text)

    except Exception as e:
        logger.error(f"LLM filter extraction failed: {e}", exc_info=True)
        return {}

# --- Qdrant Search Function ---
def query_qdrant(query: str, client: QdrantClient, collection_name: str, top_k=5, query_filter=None) -> list[dict]:
    """
    Queries a Qdrant collection using a locally generated embedding and an optional filter.
    """
    if not embedding_model:
        logger.error("Embedding model is not available. Cannot query Qdrant.")
        return []

    try:
        query_embedding = embedding_model.encode(query, show_progress_bar=False).tolist()

        search_responses = client.search(
            collection_name=collection_name,
            query_vector=query_embedding,
            query_filter=query_filter,
            limit=top_k,
            with_payload=True,
            score_threshold=relevance_threshold
        )

        return [{"text": match.payload["text"], "score": match.score} for match in search_responses]
    
    except Exception as e:
        logger.error(f"Qdrant query failed in collection '{collection_name}': {e}", exc_info=True)
        return []

# --- Main Context Retrieval Logic (MODIFIED) ---
def get_context_for_query(query: str, client: QdrantClient, collection_name: str) -> str:
    """
    Orchestrates the process of analyzing a query, building filters, and retrieving context.
    """
    extracted_filters = get_filters_from_llm(query)
    logger.info(f"Extracted filters from LLM for collection '{collection_name}': {extracted_filters}")

    search_filter_conditions = []
    
    if "min_satisfaction" in extracted_filters and isinstance(extracted_filters["min_satisfaction"], int):
        search_filter_conditions.append(
            models.FieldCondition(key="client_satisfaction", range=models.Range(gte=extracted_filters["min_satisfaction"]))
        )
    
    if "department" in extracted_filters and isinstance(extracted_filters["department"], str):
        search_filter_conditions.append(
            models.FieldCondition(key="department", match=models.MatchValue(value=extracted_filters["department"]))
        )
    
    if "job_title" in extracted_filters and isinstance(extracted_filters["job_title"], str):
        search_filter_conditions.append(
            models.FieldCondition(key="job_title", text_in=extracted_filters["job_title"])
        )

    # --- NEW: Add filter conditions for the new fields ---
    if "employee_id" in extracted_filters and isinstance(extracted_filters["employee_id"], str):
        search_filter_conditions.append(
            models.FieldCondition(key="employee_id", match=models.MatchValue(value=extracted_filters["employee_id"]))
        )

    if "full_name" in extracted_filters and isinstance(extracted_filters["full_name"], str):
        search_filter_conditions.append(
            models.FieldCondition(key="full_name", match=models.MatchText(text=extracted_filters["full_name"]))
        )
    
    if "location" in extracted_filters and isinstance(extracted_filters["location"], str):
        search_filter_conditions.append(
            models.FieldCondition(key="location", match=models.MatchText(text=extracted_filters["location"]))
        )
        
    if "email" in extracted_filters and isinstance(extracted_filters["email"], str):
        search_filter_conditions.append(
            models.FieldCondition(key="email", match=models.MatchText(text=extracted_filters["email"]))
        )
        
    if "start_date" in extracted_filters and isinstance(extracted_filters["start_date"], str):
        # Using MatchText for a simple text match on the date field
        search_filter_conditions.append(
            models.FieldCondition(key="start_date", match=models.MatchText(text=extracted_filters["start_date"]))
        )
        
    if "skills" in extracted_filters and isinstance(extracted_filters["skills"], str):
        search_filter_conditions.append(
            models.FieldCondition(key="skills", match=models.MatchText(text=extracted_filters["skills"]))
        )
        
    if "project_history" in extracted_filters and isinstance(extracted_filters["project_history"], str):
        search_filter_conditions.append(
            models.FieldCondition(key="project_history", match=models.MatchText(text=extracted_filters["project_history"]))
        )

    final_filter = models.Filter(must=search_filter_conditions) if search_filter_conditions else None
    
    qdrant_results = query_qdrant(query, client, collection_name, query_filter=final_filter)

    if not qdrant_results:
        logger.warning("No results returned from Qdrant for query: '%s' in collection '%s'", query, collection_name)
        return ""

    relevant_passages = [res["text"] for res in qdrant_results]
    
    if not relevant_passages:
        logger.warning(
            f"No results in collection '{collection_name}' met the relevance threshold of {relevance_threshold}. "
            f"Discarding context."
        )
        return ""
    
    logger.info(
        f"Retrieved {len(relevant_passages)} relevant passages from collection '{collection_name}' for the context."
    )
    return "\n---\n".join(relevant_passages)