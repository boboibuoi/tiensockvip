def get_employee_qa_prompt(context: str, query: str) -> tuple[str, str]:
    """Generates the system and user prompts for the employee directory Q&A."""
    system_prompt = (
        "You are an expert HR assistant. Your task is to answer questions about employees "
        "based on the internal profile data provided as context. Synthesize information from different profiles if needed. "
        "If you list employees, provide their full name and job title. Be friendly and professional."
    )
    user_prompt = (
        f"""Based ONLY on the context containing employee profiles below, provide a clear and concise answer to the user's query.
        If the context does not contain the answer, you MUST state that you could not find the information. Do not use outside knowledge.

        ## Context ##
        {context}

        ## User Query ##
        "{query}"
        """
    )
    return system_prompt, user_prompt


def get_filter_extraction_prompt(query: str) -> tuple[str, str]:
    """
    Generates the system and user prompts for extracting structured filters from a user query.
    """
    system_prompt = """
    You are an expert at analyzing user queries and extracting structured search filters.
    Your output MUST be a single, valid JSON object and nothing else.
    The valid keys for the JSON object are: "department" (string), "job_title" (string), "min_satisfaction" (integer), "employee_id" (string), "full_name" (string), "location" (string), "email" (string), "start_date" (string), "skills" (string), and "project_history" (string).
    If the user's query does not contain any information for a filter, do not include the key in the JSON.
    If no filters are found at all, return an empty JSON object {}.
    """
    
    user_prompt = f"Analyze the following user query and extract the filters:\n\n'{query}'"
    
    return system_prompt, user_prompt