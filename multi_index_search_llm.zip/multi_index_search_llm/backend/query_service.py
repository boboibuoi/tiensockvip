import logging
import config
# --- NEW IMPORT ---
from qdrant_client import QdrantClient

from backend import context_layer

logger = logging.getLogger(config.APP_NAME)

# Celery App Import
try:
    from celery_app import celery_app
    logger.info("celery_app has been successfully imported from Celery")

except ImportError as e:
    logger.exception("An exception has occured when importing celery_app instance")
    raise

@celery_app.task(bind=True, max_retries=3, acks_late=True)
def process_employee_query_task(self, query: str, target_department: str):
    task_id = self.request.id
    logger.info(f"[CONTEXT TASK START] Task ID: {task_id}. Dept: '{target_department}', Query: '{query}'")

    try:
        # --- MODIFIED: Initialize Qdrant client ---
        client = QdrantClient(host=config.QDRANT_HOST, port=config.QDRANT_PORT)
        
        dept_info = config.DEPARTMENT_CONFIG.get(target_department)
        if not dept_info:
            logger.warning(f"No config found for department '{target_department}'. Skipping.")
            return {"status": "skipped_no_config", "context": None, "source": target_department}
            
        # --- MODIFIED: Use qdrant_collection ---
        collection_name = dept_info['qdrant_collection']
        
        # Check if the collection exists by trying to get its info
        try:
             client.get_collection(collection_name=collection_name)
        except Exception:
            logger.warning(f"Collection '{collection_name}' not found. Skipping department '{target_department}'.")
            return {"status": "skipped_no_collection", "context": None, "source": target_department}

        # --- MODIFIED: Pass client and collection_name ---
        context_from_dept = context_layer.get_context_for_query(query, client, collection_name)
        
        if context_from_dept:
            logger.info(f"[CONTEXT TASK SUCCESS] Task ID: {task_id}. Found context in '{target_department}'.")
            return {"status": "success", "context": context_from_dept, "source": target_department}
        else:
            logger.info(f"[CONTEXT TASK SUCCESS] Task ID: {task_id}. No relevant context found in '{target_department}'.")
            return {"status": "no_context", "context": None, "source": target_department}

    except Exception as e:
        logger.error(f"Unhandled exception in context task {task_id} for department {target_department}: {e}", exc_info=True)
        return {"status": "failed", "context": None, "source": target_department, "error": str(e)}