import logging
import math
from enum import Enum
import uuid

import psycopg2
from celery import chain
from celery.exceptions import MaxRetriesExceededError
# --- NEW IMPORTS ---
from qdrant_client import QdrantClient, models
from sentence_transformers import SentenceTransformer

import config
from backend import db_pool_setup

logger = logging.getLogger(config.APP_NAME)

# Celery App Import
try:
    from celery_app import celery_app
    logger.info("text_embedding.py: celery_app imported successfully.")
except ImportError as e:
    logger.exception("text_embedding.py: Could not import celery_app. %s", e)
    raise

# --- NEW: Initialize sentence transformer model (cached at module level) ---
# This is thread-safe and efficient for Celery workers.
try:
    embedding_model = SentenceTransformer(config.LOCAL_EMBEDDING_MODEL_NAME)
    logger.info(f"Successfully loaded sentence-transformer model: {config.LOCAL_EMBEDDING_MODEL_NAME}")
except Exception as e:
    logger.critical(f"Failed to load sentence-transformer model: {e}", exc_info=True)
    embedding_model = None


# --- Status Management Enum ---
class ProcessingStatus(Enum):
    PENDING = 'pending'
    COMPLETED = 'completed'
    FAILED = 'failed'

# --- Main Dispatcher Function (Modified to use qdrant_collection) ---
def launch_embedding_tasks():
    logger.info("--- Starting Multi-Department Embedding Dispatch ---")
    total_tasks_launched = 0

    for dept_name, dept_config in config.DEPARTMENT_CONFIG.items():
        table_name = dept_config.get('postgres_table')
        collection_name = dept_config.get('qdrant_collection') # MODIFIED

        if not table_name or not collection_name:
            logger.warning(f"Skipping department '{dept_name}' due to missing configuration.")
            continue

        all_pending_ids = fetch_pending_ids_for_department(table_name)

        if not all_pending_ids:
            logger.info(f"No pending employees found for department '{dept_name}'.")
            continue
        
        batch_size = getattr(config, 'QDRANT_UPSERT_BATCH_SIZE', 90) # MODIFIED
        
        for i in range(0, len(all_pending_ids), batch_size):
            batch_ids = all_pending_ids[i : i + batch_size]
            
            try:
                # MODIFIED: pass collection_name to the chain
                task_chain = chain(
                    prepare_employee_vectors_task.s(batch_ids, table_name, dept_name), 
                    upsert_vectors_task.s(collection_name, table_name) 
                )
                task_chain.apply_async(queue="embedding")
                total_tasks_launched += 1
                logger.info(f"Dispatched task chain for {dept_name} with {len(batch_ids)} IDs.")
            except Exception as e:
                logger.exception(f"Failed to dispatch Celery task chain for {dept_name}: {e}")

    logger.info(f"--- Finished Dispatching. Total tasks launched: {total_tasks_launched} ---")
    return {"status": "dispatch_complete", "total_tasks_launched": total_tasks_launched}

# --- Database Helper Functions ---
# ... (these functions are correct, no changes needed)
def fetch_pending_ids_for_department(table_name: str) -> list:
    logger.info(f"Fetching pending IDs from table: '{table_name}'")
    try:
        with db_pool_setup.db_connection() as conn:
            with conn.cursor() as cur:
                query = f"SELECT employee_id FROM {table_name} WHERE embedding_status = %s ORDER BY employee_id"
                cur.execute(query, (ProcessingStatus.PENDING.value,))
                return [row[0] for row in cur.fetchall()]
    except Exception as e:
        logger.exception(f"Error fetching pending IDs from {table_name}: {e}")
        return []

def fetch_employees_by_ids(employee_ids: list, table_name: str) -> list:
    if not employee_ids:
        return []
    try:
        with db_pool_setup.db_connection() as conn:
            with conn.cursor() as cur:
                query = f"""
                    SELECT 
                        employee_id, full_name, job_title, start_date, 
                        skills, project_history, email, location 
                    FROM {table_name} 
                    WHERE employee_id = ANY(%s)
                """
                cur.execute(query, (employee_ids,))
                return [dict(zip([col.name for col in cur.description], row)) for row in cur.fetchall()]
    except Exception as e:
        logger.exception(f"Error fetching employee data from {table_name}: {e}")
        return []

def update_employee_status_in_db(employee_ids: list, table_name: str, status: ProcessingStatus):
    if not employee_ids:
        return
    logger.debug(f"Updating status to '{status.value}' for {len(employee_ids)} IDs in table '{table_name}'")
    try:
        with db_pool_setup.db_connection() as conn:
            with conn.cursor() as cur:
                query = f"UPDATE {table_name} SET embedding_status = %s WHERE employee_id = ANY(%s)"
                cur.execute(query, (status.value, employee_ids))
    except Exception as e:
        logger.error(f"DB status update to '{status.value}' failed for table '{table_name}': {e}", exc_info=True)


# --- Celery Tasks (HEAVILY MODIFIED) ---
@celery_app.task(bind=True, max_retries=3, default_retry_delay=60, acks_late=True)
def prepare_employee_vectors_task(self, employee_ids_batch: list, table_name: str, dept_name: str):
    logger.info(f"[PREPARE TASK START] Preparing {len(employee_ids_batch)} employees from '{table_name}' ({dept_name}).")
    
    if not embedding_model:
        logger.error("Embedding model is not available. Task cannot proceed.")
        raise RuntimeError("SentenceTransformer model not loaded.")

    employees = fetch_employees_by_ids(employee_ids_batch, table_name)
    if not employees:
        logger.warning(f"No employee data found for IDs in '{table_name}'. Task will end.")
        return {"status": "no_data", "points": []}

    texts_to_embed = []
    employee_map = {}
    for emp in employees:
        text = (
            f"Name: {emp.get('full_name', '')}. "
            f"Title: {emp.get('job_title', '')}. "
            f"Department: {dept_name}. "
            f"Location: {emp.get('location', '')}. "
            f"Contact Email: {emp.get('email', '')}. "
            f"Start Date: {str(emp.get('start_date', ''))}. "
            f"Skills: {emp.get('skills', '')}. "
            f"Projects: {emp.get('project_history', '')}"
        )
        texts_to_embed.append(text)
        employee_map[text] = emp

    try:
        embeddings = embedding_model.encode(texts_to_embed, show_progress_bar=False).tolist()

    except Exception as e:
        logger.warning(f"Task for {table_name} failed on embedding attempt {self.request.retries + 1}. Error: {e}")
        try:
            raise self.retry(exc=e, countdown=60)
        except MaxRetriesExceededError:
            logger.error(f"Task for {table_name} has failed permanently. Marking records as FAILED.")
            update_employee_status_in_db(employee_ids_batch, table_name, ProcessingStatus.FAILED)
            raise e

    points_to_upsert = []
    namespace = uuid.UUID('f2b4e448-86d6-4c28-8b1b-5e6e5e0c8b4e')

    for i, text in enumerate(texts_to_embed):
        emp = employee_map[text]
        employee_id_str = str(emp['employee_id'])
        point_id = str(uuid.uuid5(namespace, employee_id_str))

        points_to_upsert.append({
            "id": point_id,
            "vector": embeddings[i],
            "payload": {
                "text": text, 
                "employee_id": employee_id_str, 
                "full_name": emp.get('full_name', ''),
                "job_title": emp.get('job_title', ''), 
                "department": dept_name, 
                "location": emp.get('location', ''),
                "email": emp.get('email', ''), 
                "start_date": str(emp.get('start_date', '')),
                "client_satisfaction": int(emp.get('client_satisfaction', 0)),
                # --- NEWLY ADDED FIELDS ---
                "skills": emp.get('skills', ''),
                "project_history": emp.get('project_history', '')
            }
        })

    logger.info(f"[PREPARE TASK SUCCESS] Prepared {len(points_to_upsert)} points for '{table_name}'.")
    return {"status": "prepared", "points": points_to_upsert}


@celery_app.task(bind=True, max_retries=3, acks_late=True)
def upsert_vectors_task(self, vectors_payload: dict, collection_name: str, table_name: str):
    # This task does not need any changes.
    points = vectors_payload.get("points")
    if not points:
        logger.warning(f"Upsert task skipped for collection '{collection_name}': No points received from prepare task.")
        return {"status": "skipped"}

    logger.info(f"[UPSERT TASK START] Upserting {len(points)} points to Qdrant collection: '{collection_name}'")

    try:
        qdrant_client = QdrantClient(host=config.QDRANT_HOST, port=config.QDRANT_PORT)

        try:
            qdrant_client.get_collection(collection_name=collection_name)
        except Exception:
            logger.info(f"Collection '{collection_name}' not found. Creating it now.")
            qdrant_client.create_collection(
                collection_name=collection_name,
                vectors_config=models.VectorParams(
                    size=config.LOCAL_EMBEDDING_MODEL_DIMENSION,
                    distance=models.Distance.COSINE
                ),
            )

        point_structs = [models.PointStruct(**point) for point in points]

        qdrant_client.upsert(
            collection_name=collection_name,
            points=point_structs,
            wait=True
        )

        upserted_ids = [int(p.payload["employee_id"]) for p in point_structs]
        update_employee_status_in_db(upserted_ids, table_name, ProcessingStatus.COMPLETED)

        logger.info(f"[UPSERT TASK SUCCESS] Successfully upserted {len(points)} points to '{collection_name}'.")
        return {"status": "success", "count": len(points), "collection_name": collection_name}

    except Exception as e:
        logger.error(f"[UPSERT TASK RETRY] Upsert failed for collection '{collection_name}': {e}", exc_info=True)
        try:
            raise self.retry(exc=e)
        except MaxRetriesExceededError:
            logger.error(f"Upsert task for {collection_name} has failed permanently. Marking records as FAILED.")
            if points:
                failed_ids = [int(p["payload"]["employee_id"]) for p in points]
                update_employee_status_in_db(failed_ids, table_name, ProcessingStatus.FAILED)
            raise e