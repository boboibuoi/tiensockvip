import config
from celery import Celery, signals
from backend import db_pool_setup

if not config.CELERY_BROKER_URL:
    raise ValueError("An error has occurred. CELERY_BROKER_URL not found in config")

# --- ARCHITECTURE CHANGE: Use a Router Class for all routing logic ---
class ProjectRouter:
    """
    A Celery router class to direct tasks to the correct queues.
    This is the standard, most robust way to handle custom routing.
    """
    def route_for_task(self, task, args=None, kwargs=None):
        # Check the name of the task being routed.
        
        # 1. Dynamic routing for our main query task.
        if task == 'backend.query_service.process_employee_query_task':
            if kwargs and 'target_department' in kwargs:
                dept = kwargs['target_department']
                if dept in config.DEPARTMENT_CONFIG:
                    # --- MODIFIED: Use qdrant_collection for the queue name ---
                    collection_name = config.DEPARTMENT_CONFIG[dept]['qdrant_collection']
                    # Return the routing dictionary for the specific queue.
                    return {
                        'queue': f'query-{collection_name}'
                    }
        
        # 2. Static routing for embedding tasks.
        if task.startswith('backend.text_embedding.'):
            return {'queue': 'embedding'}
        
        # 3. Static routing for logging tasks.
        if task.startswith('backend.chatlog_storage.'):
            return {'queue': 'logging'}
            
        # Return None for any other tasks to use the default queue.
        return None

# --- Celery App Initialization ---
celery_app = Celery(
    config.APP_NAME,
    broker=config.CELERY_BROKER_URL,
    backend=config.CELERY_RESULT_BACKEND,
    include=[
        'backend.text_embedding',
        'backend.query_service',
        'backend.chatlog_storage'
    ]
)

celery_app.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='Asia/Ho_Chi_Minh',
    enable_utc=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,

    ## ARCHITECTURE CHANGE:
    ## The task_routes config now points to an instance of our Router Class.
    ## Note the comma to make it a tuple, which is standard practice.
    task_routes = (ProjectRouter(),)
)

import logging
logger = logging.getLogger(config.APP_NAME)

# --- Worker Signals (Unchanged) ---
@signals.worker_process_init.connect
def initialize_worker_process(**kwargs):
    logger.info("Initializing Celery worker process...")
    try:
        db_pool_setup.initialize_pool()
        logger.info("Database pool initialized for worker process.")
    except Exception as e:
        logger.error(f"Error initializing database pool in worker: {e}", exc_info=True)

@signals.worker_process_shutdown.connect
def shutdown_worker_process(**kwargs):
    logger.info("Shutting down Celery worker process")
    try:
        db_pool_setup.close_pool()
    except Exception as e:
        logger.error(f"Error closing database pool in worker: {e}", exc_info=True)