import sys
import os
import logging
import time

import chainlit as cl
from chainlit.element import TaskList, Task
from chainlit.message import Message
from celery import group
from celery.result import GroupResult

# --- Project Root Path Setup (retained) ---
project_root = None
try:
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
except Exception as e:
    logging.basicConfig(level=logging.ERROR)
    logging.error(f"CRITICAL: Failed to set project root path: {e}", exc_info=True)
    raise

# --- Logging and Configuration Setup (retained) ---
try:
    import config
    logger = logging.getLogger(config.APP_NAME)
    if hasattr(config, 'setup_logging') and callable(config.setup_logging):
        config.setup_logging()
        logger.info(f"Logging configured. Project root '{project_root}' in sys.path.")
    else:
        logger.warning(f"config.setup_logging() not found/callable.")
except Exception as e:
    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    logger.error(f"Error during config/logging setup: {e}. Using basic logger.", exc_info=True)

# --- ARCHITECTURE CHANGE: Imports moved here from query_service ---
from backend import prompt_templates
from openai import OpenAI
from tenacity import retry, stop_after_attempt, wait_fixed

# --- Import Celery and Backend Modules ---
try:
    from celery_app import celery_app
    from backend.query_service import process_employee_query_task 
    from backend.chatlog_storage import buffer_chat_log
    logger.info("Successfully imported application modules for IntelChat.")
except ImportError as e:
    logger.error("ImportError while loading application modules.", exc_info=True)
    raise

# --- LLM helper functions (retained) ---
def initialize_selected_llm(model_choice):
    safe_model_choice = model_choice.strip()
    try:
        if safe_model_choice == config.MISTRAL_MODEL_CHOICE.strip():
            return OpenAI(api_key=config.MISTRAL_API_KEY, base_url="https://api.mistral.ai/v1")
        elif safe_model_choice == config.OPENAI_MODEL_CHOICE.strip():
            return OpenAI(api_key=config.OPENAI_API_KEY)
        elif safe_model_choice == config.DEEPSEEK_MODEL_CHOICE.strip():
            return OpenAI(base_url=config.DEEPSEEK_BASEURL, api_key=config.DEEPSEEK_API_KEY)
        else:
            raise ValueError(f"Unsupported model: '{safe_model_choice}")
    except Exception as e:
        logger.critical(f"LLM Client initialization failed: {e}", exc_info=True)
        return None

@retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
def call_llm_chat(client, system_prompt, user_prompt, model_name: str):
    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}]
        )
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"LLM API call failed: {e}", exc_info=True)
        raise

# --- Celery Task Helper Function (retained) ---
async def await_group_task_result(result_obj: GroupResult, task_list_ui: TaskList, timeout: int = 20):
    """
    Polls a Celery GroupResult object until it's ready, or until a timeout is reached.
    """
    task_list_ui.tasks[0].status = cl.TaskStatus.RUNNING
    await task_list_ui.send()
    
    start_time = time.time()
    
    try:
        # We poll the state instead of using blocking .get() to avoid locking the UI
        while not result_obj.ready():
            if time.time() - start_time > timeout:
                logger.warning(
                    f"Task group {result_obj.id} timed out after {timeout} seconds. "
                    "Returning available results and ignoring stuck tasks."
                )

                break 
            
            await cl.sleep(1) # Polling interval
        
        # Check if the group is ready or if we timed out.
        if result_obj.ready() and result_obj.successful():
            task_list_ui.tasks[0].status = cl.TaskStatus.DONE
            await task_list_ui.send()
            return result_obj.get()
        else:
            # Handle the case where the group did not complete within the timeout.
            task_list_ui.tasks[0].status = cl.TaskStatus.FAILED # Or another appropriate status
            task_list_ui.tasks[0].description = "Some tasks failed or timed out."
            await task_list_ui.send()

            return []
            
    except Exception as e:
        logger.error(f"Error while awaiting group task {result_obj.id}: {e}", exc_info=True)
        return []

# --- Chainlit Application Logic ---

@cl.on_chat_start
async def start_chat():
    cl.user_session.set("chat_id", f"chat_{int(time.time())}")
    cl.user_session.set("llm_choice", config.OPENAI_MODEL_CHOICE)
    await cl.Message(
        content="Welcome to IntelChat - the company's employee Q&A chatbot. What can I help you with?",
        author="IntelChat"
    ).send()

    ## CORRECTED ACTION SYNTAX
    await cl.Message(
        content="You can change the AI model at any time.",
        author="IntelChat",
        actions=[
            cl.Action(
                name="change_model", 
                value="change_model", 
                payload={"value": "change_model"}, 
                label="⚙️ Change Model"
            )
        ]
    ).send()

@cl.action_callback("change_model")
async def on_change_model(action: cl.Action):
    ## CORRECTED ACTION SYNTAX
    model_actions = [
        cl.Action(
            name="llm_selected", 
            value=config.OPENAI_MODEL_CHOICE, 
            payload={"value": config.OPENAI_MODEL_CHOICE}, 
            label=f"🤖 {config.OPENAI_MODEL_CHOICE}"
        ),
        cl.Action(
            name="llm_selected", 
            value=config.MISTRAL_MODEL_CHOICE, 
            payload={"value": config.MISTRAL_MODEL_CHOICE}, 
            label=f"🤖 {config.MISTRAL_MODEL_CHOICE}"
        ),
        cl.Action(
            name="llm_selected", 
            value=config.DEEPSEEK_MODEL_CHOICE, 
            payload={"value": config.DEEPSEEK_MODEL_CHOICE}, 
            label=f"🤖 {config.DEEPSEEK_MODEL_CHOICE}"
        )
    ]
    await cl.Message(
        content="Please select your preferred AI model:",
        author="IntelChat",
        actions=model_actions
    ).send()
    
@cl.action_callback("llm_selected")
async def on_llm_selected(action: cl.Action):
    ## CORRECTED VALUE RETRIEVAL
    chosen_llm = action.payload.get('value')
    if chosen_llm:
        cl.user_session.set("llm_choice", chosen_llm)
        await cl.Message(
            content=f"Model has been set to **{chosen_llm}**. You can now ask me questions about our employees.",
            author="IntelChat"
        ).send()

@cl.on_message
async def main_logic(message: Message):
    query_text = message.content
    chat_id = cl.user_session.get("chat_id")
    llm_choice = cl.user_session.get("llm_choice")
    buffer_chat_log(chat_id, "user", query_text)

    task_list = TaskList(tasks=[
        Task(title="Searching all departments for context...", status=cl.TaskStatus.RUNNING)
    ])
    await task_list.send()

    try:
        departments_to_query = config.DEPARTMENTS
        task_group = group(
            process_employee_query_task.s(query=query_text, target_department=dept)
            for dept in departments_to_query
        )
        
        group_result = task_group.apply_async()
        
        # ARCHITECTURE CHANGE: Pass the entire group_result object, not just its ID.
        results = await await_group_task_result(group_result, task_list)
        
    except Exception as e:
        logger.error(f"Failed to dispatch Celery group task: {e}", exc_info=True)
        await task_list.remove()
        await cl.Message(content="Error: Could not connect to the processing service.").send()
        return

    all_context_fragments = []
    searched_sources = []
    for res in results:
        if isinstance(res, dict) and res.get('status') == 'success' and res.get('context'):
            all_context_fragments.append(f"Context from {res['source']} Department\n{res['context']}")
        if isinstance(res, dict) and 'source' in res:
            searched_sources.append(res['source'])

    if not all_context_fragments:
        await cl.Message(content="I'm sorry, I could not find any relevant employee profiles for your query across any department.", author="IntelChat").send()
        await task_list.remove()
        return

    final_context = "\n\n---\n\n".join(all_context_fragments)
    system_prompt, user_prompt = prompt_templates.get_employee_qa_prompt(final_context, query_text)

    llm_client = initialize_selected_llm(llm_choice)
    
    model_to_use = None
    if llm_choice == config.OPENAI_MODEL_CHOICE: model_to_use = config.OPENAI_MODEL
    elif llm_choice == config.MISTRAL_MODEL_CHOICE: model_to_use = config.MISTRAL_MODEL
    elif llm_choice == config.DEEPSEEK_MODEL_CHOICE: model_to_use = config.DEEPSEEK_MODEL
    
    if llm_client and model_to_use:
        answer = call_llm_chat(llm_client, system_prompt, user_prompt, model_to_use)
    else:
        answer = "Error: Could not initialize the selected AI model to generate a final answer."

    await cl.Message(content=answer, author=llm_choice).send()

    if searched_sources:
        source_str = ", ".join(sorted(list(set(searched_sources))))
        await cl.Message(content=f"*(Searched in: {source_str})*", author="IntelChat", indent=1).send()

    buffer_chat_log(chat_id, "assistant", answer)
    await task_list.remove()