import csv
import json
import random
import logging
import os
from faker import Faker

try:
    import config
except ImportError:
    print("Error: Could not import config.py. Make sure this script is in the project root.")
    exit(1)

NUM_EMPLOYEES_PER_DEPT = 300  
OUTPUT_DIR = "data"

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
fake = Faker()


ROLES_BY_DEPT = {
    "Engineering": ["Software Engineer", "Senior Software Engineer", "QA Tester", "DevOps Engineer", "Data Scientist", "Cloud Architect"],
    "Sales": ["Account Executive", "Sales Development Rep", "Customer Success Manager", "Sales Manager", "Solutions Architect"],
    "HR": ["Recruiter", "HR Business Partner", "Compensation Analyst", "HR Generalist"],
    "Marketing": ["Content Marketer", "SEO Specialist", "Product Marketing Manager", "Digital Ads Manager"],
    "Finance": ["Accountant", "Financial Analyst", "Controller", "FP&A Manager"],
    "Operations": ["Operations Manager", "Business Analyst", "Supply Chain Specialist", "Process Improvement Lead"]
}

SKILLS_BY_DEPT = {
    "Engineering": ["Python", "Go", "Java", "AWS", "Kubernetes", "Docker", "Terraform", "React", "PostgreSQL", "MongoDB"],
    "Sales": ["Salesforce", "Lead Generation", "Contract Negotiation", "CRM Management", "Public Speaking", "Client Relationship"],
    "HR": ["Workday", "Talent Acquisition", "Employee Relations", "Onboarding", "Benefits Administration", "Compliance"],
    "Marketing": ["HubSpot", "Google Analytics", "SEO/SEM", "Content Strategy", "Email Marketing", "Social Media Advertising"],
    "Finance": ["Excel", "QuickBooks", "Financial Modeling", "Risk Analysis", "Auditing", "SAP"],
    "Operations": ["Six Sigma", "Process Mapping", "Logistics", "Inventory Management", "ERP Systems", "Data Analysis"]
}

LOCATIONS = ["Ho Chi Minh City, VN", "Hanoi, VN", "Da Nang, VN", "Singapore, SG", "Kuala Lumpur, MY"]

def generate_employee_row(department_name):
    """Generates a single, highly detailed employee data row."""
    full_name = fake.name()
    email = f"{full_name.lower().replace(' ', '.')}{random.randint(1,99)}@example-corp.com"
    role = random.choice(ROLES_BY_DEPT[department_name])
    
    skills = json.dumps(random.sample(SKILLS_BY_DEPT[department_name], k=random.randint(3, 6)))
    
    project_history = json.dumps([{
        "project_name": fake.bs().title() + " Initiative",
        "client": fake.company(),
        "year": fake.year(),
        "description": fake.catch_phrase(),
        "outcome": random.choice(["Increased efficiency by 15%", "Reduced costs by 10%", "Launched new product feature", "Achieved 95% client satisfaction"])
    } for _ in range(random.randint(1, 4))])
    
    return [
        full_name,
        role,
        fake.date_between(start_date="-8y", end_date="today").isoformat(),
        skills,
        project_history,
        'pending', 
        email,
        random.choice(LOCATIONS)
    ]

def generate_csv_files():
    """Generates a CSV file for each department defined in the config."""
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        logger.info(f"Created output directory: ./{OUTPUT_DIR}")

    logger.info(f"Starting CSV generation for {len(config.DEPARTMENT_CONFIG)} departments...")

    for dept_name, dept_info in config.DEPARTMENT_CONFIG.items():
        table_name = dept_info['postgres_table']
        file_path = os.path.join(OUTPUT_DIR, f"{table_name}.csv")
        
        header = [
            'full_name',
            'job_title',
            'start_date',
            'skills',
            'project_history',
            'embedding_status',
            'email',
            'location'
        ]

        try:
            with open(file_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(header)
                
                for _ in range(NUM_EMPLOYEES_PER_DEPT):
                    row = generate_employee_row(dept_name)
                    writer.writerow(row)
            
            logger.info(f"Successfully generated '{file_path}' with {NUM_EMPLOYEES_PER_DEPT} records.")

        except Exception as e:
            logger.error(f"Failed to generate CSV for {dept_name}: {e}")

    logger.info("All CSV files have been generated.")