import argparse
import logging
import sys
import os

# Add project root to path to ensure modules are found
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Now import project modules
import config
from backend import text_embedding
from backend import db_pool_setup

try:
    if hasattr(config, 'setup_logging'):
        config.setup_logging()
    logger = logging.getLogger(config.APP_NAME)
except Exception:
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)
    logger.warning("Resorted to basic logging configuration.")

def run_embedding_generation():
    """Triggers Celery tasks to generate embeddings for all pending employees."""
    logger.info("Attempting to launch embedding generation tasks for all departments...")
    
    # CRITICAL FIX: Initialize the database pool before use, as seen in your old main.py.
    db_pool_setup.initialize_pool()

    try:
        # This function can now successfully connect to the database to find pending records.
        text_embedding.launch_embedding_tasks()
        logger.info("Embedding generation tasks successfully dispatched. Check Celery worker logs for progress.")
    except Exception as e:
        logger.error(f"Failed to launch embedding generation tasks: {e}", exc_info=True)
    finally:
        # CRITICAL FIX: Cleanly close the pool when the script is done.
        logger.info("Closing database pool...")
        db_pool_setup.close_pool()
        logger.info("Database pool closed.")

def main():
    """Parses command-line arguments and executes the corresponding administrative action."""
    parser = argparse.ArgumentParser(description="Corporate Directory Admin CLI")
    parser.add_argument(
        "action",
        choices=["generate-embeddings"],
        help="The administrative action to perform."
    )
    args = parser.parse_args()

    if args.action == "generate-embeddings":
        run_embedding_generation()
    else:
        logger.error(f"Unknown action: {args.action}")
        parser.print_help()

if __name__ == "__main__":
    main()